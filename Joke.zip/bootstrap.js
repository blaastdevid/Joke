// Joke -- bootstrap.js
var app = this;
app.on('connected', function(){
    console.log('Connected to Backend');
});